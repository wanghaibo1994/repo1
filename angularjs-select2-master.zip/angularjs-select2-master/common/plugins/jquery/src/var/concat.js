define([
	"./arr"
], function( arr ) {
	return arr.concat;
});
